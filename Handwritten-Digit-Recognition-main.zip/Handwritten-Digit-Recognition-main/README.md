<h1>Handwritten Digit Recognition using TensorFlow and with Convolutional Neural Network (CNN)</h1>

<h2>Here is a Flow of Project</h2>

<h4>Step 1: View of a Project </h4>
<img src = "https://github.com/Tanay7227/Handwritten-Digit-Recognition/blob/main/Hand-Written-Digit-Recognition-master/images/0.png">
<h4>Step 2: Write Any Number to Predict the value (Let Take example of Zero "0")</h4>
<img src = "https://github.com/Tanay7227/Handwritten-Digit-Recognition/blob/main/Hand-Written-Digit-Recognition-master/images/1.png">
<h4>Step 3: Here is a Prediction View </h4>
<img src = "https://github.com/Tanay7227/Handwritten-Digit-Recognition/blob/main/Hand-Written-Digit-Recognition-master/images/2.png">
<h4>Step 3: Here is a Some Examples</h4>
<img src = "https://github.com/Tanay7227/Handwritten-Digit-Recognition/blob/main/Hand-Written-Digit-Recognition-master/images/3.png">
<img src = "https://github.com/Tanay7227/Handwritten-Digit-Recognition/blob/main/Hand-Written-Digit-Recognition-master/images/4.png">
<img src = "https://github.com/Tanay7227/Handwritten-Digit-Recognition/blob/main/Hand-Written-Digit-Recognition-master/images/5.png">


